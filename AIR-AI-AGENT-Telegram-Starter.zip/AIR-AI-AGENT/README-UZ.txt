AIR AI AGENT — TELEGRAM BOT + OMNIROUTE

1) ZIP faylni oching.
2) Shu papkada .env.example faylidan nusxa olib, nusxasini .env deb nomlang.
3) .env ichiga BotFather tokenini kiriting.
4) OmniRoute dasturidagi API sozlamalaridan aniq quyidagilarni topib kiriting:
   - API base URL (OpenAI-compatible endpoint)
   - API key
   - Model ID
   Eslatma: .env.example ichidagi PORT va model qiymatlari namuna. OmniRoute'dagi haqiqiy qiymatlarni ishlating.
5) Node.js 20 yoki undan yangiroq versiya o‘rnatilgan bo‘lsin.
6) Terminalni loyiha papkasida ochib quyidagilarni bajaring:

   npm install
   npm start

7) Telegram'da botingizga /start yuboring va sinab ko‘ring.

XAVFSIZLIK:
- .env faylini hech kimga yubormang.
- Bot tokeni va API kalitini ommaga chiqarmang.
- Bu boshlang‘ich chat bot. Hozircha haqiqiy reys qidirish, bronlash yoki to‘lov tizimi ulanmagan.
- OmniRoute endpoint/model qiymatlarini taxmin qilmang; o‘zingizdagi OmniRoute API sozlamalaridan oling.
